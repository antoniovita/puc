def areafunc (dim1, dim2):
    area = float(dim1)*float(dim2)
    return area

dim1 = float(input('Insira a primeira dimensão:'))
dim2 = float(input('Insira a segunda dimensão:'))


areafunc(dim1, dim2)
